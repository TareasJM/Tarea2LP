public class ColorCreator extends AbstractCreator{

	public Bloque crearBloque(){
		System.out.println("ColorCreator");
		return new Bloque();
	}

}