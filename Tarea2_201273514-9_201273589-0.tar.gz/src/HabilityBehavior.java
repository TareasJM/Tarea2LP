public interface HabilityBehavior{

	public int Hability();

}