public class Bloque{

	/******** Funcion: DestruirBloque **************
	Descripcion: destruye bloque
	Parametros: ninguno
	Retorno: entero -1
	************************************************/
	public int DestruirBloque(){
		return -1;
	}
}