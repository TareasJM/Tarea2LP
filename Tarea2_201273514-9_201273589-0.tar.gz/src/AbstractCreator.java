public abstract class AbstractCreator{

	public abstract Bloque crearBloque();
}