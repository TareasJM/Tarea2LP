public class HabilityT2 implements HabilityBehavior{

	/******** Funcion:Hability **************
	Descripcion: retorna 2 que en Board significa eliminacion de la columna
	Parametros: ninguno
	Retorno: entero
	************************************************/
	public int Hability(){
		return 2;
		//destroyRow(x);
	}

}