public class HabilityT1 implements HabilityBehavior{

	/******** Funcion: Hability **************
	Descripcion: retorna 1 que en Board significa eliminacion de la fila
	Parametros: ninguno
	Retorno: entero
	************************************************/
	public int Hability(){
		return 1;
		//destroyRow(x);
	}

}