public class ComodinCreator extends AbstractCreator{

	public Bloque crearBloque(){
		System.out.println("ColorCreator");
		return new Bloque();

	}

}