Tarea2LP

========

José Miguel Castro   : 201273514-9
Marco Antonio Salinas: 201273589-0

========

Modalidades del juego:
	
	Consola: Se debe iniciar el juego con el argumento -c.
             Para mover los bloques se debe ingresar fila1-columna1 fila2-columna2
    
    Intefaz Gráfica: No argumento especificado al iniciar.
    		         Para mover los bloques, hacer click en cada uno.

Configurar Meta: Para configurar los bloques a romper se debe ingresar al ejecutar el juego: n°Rojos n°Azul n°Naranjos n°Verdes n°Amarillos
				La meta para cada bloque son 100, si quiere modificar la meta ponga ant -Dargi = num, donde i es el argumento i desde
				el 0 al 5 y num el numero de bloques que desee.